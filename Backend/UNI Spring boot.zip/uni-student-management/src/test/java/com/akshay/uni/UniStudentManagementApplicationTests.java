package com.akshay.uni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniStudentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
